
/*============ Header Function Start ============*/
 
 

jQuery(document).ready(function(){
	jQuery(".lifestyle-menu-toggler").click(function(){
		jQuery(this).toggleClass("active");
		jQuery(".lifestyle-header-navbar").slideToggle(300);
	});
});
/*============ Header Function End ============*/

/*============ Slick-Slider Function Start ============*/
 

jQuery(document).ready(function(){
	 
	 
	
 

	jQuery("#music-podcast-slider").slick({
		 
		slidesToShow: 5,
		centerPadding: '0px',
		infinite:true,
		speed:1000,
		dots:false,
		arrows:true,
		adaptiveHeight:true,
		centerMode: true,
		variableWidth: true
	});

	function countprogress(){
		var gettotalform = jQuery('.list_step_form_main .list_step_form').length;
		var fillform = jQuery('.list_step_form_main .list_step_form.fill').length;
		var countnext = parseInt((100 / gettotalform) * fillform);
		jQuery('.form_progressbar_count span').text(countnext);
		jQuery('.form_progressbar .form_progressbar_inner').css('width',countnext+'%' )
	}

	countprogress();
	jQuery(".step_btn button").on('click', function(e) {
		var currentelement = jQuery('.list_step_form.current');
		if(jQuery(this).hasClass('next_btn')){
			if(jQuery('.list_step_form_main .list_step_form.fill').length <	 jQuery('.list_step_form_main .list_step_form').length - 1){

				e.preventDefault()
				var el = $(this);
				var validation = true;
				el.parents('#commentForm').find('input').removeClass('error');

				const validateEmail = (email) => {
					return email.match(
					  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
					);
				};

				var stepid = jQuery(currentelement).attr('step-id');
				var vorname = jQuery('input[name="vorname"]').val();
				var nachname = jQuery('input[name="nachname"]').val();
				var geburtsdatum = jQuery('input[name="geburtsdatum"]').val();
				var email = jQuery('input[name="email"]').val();
				var tel = jQuery('input[name="tel"]').val();
				if(stepid == 'step-1'){
					if(!vorname){
						jQuery('input[name="vorname"]').addClass('error');
					}

					if(!nachname){
						jQuery('input[name="nachname"]').addClass('error');
					}

					if(!geburtsdatum){
						jQuery('input[name="geburtsdatum"]').addClass('error');
					}

					if(!email){
						jQuery('input[name="email"]').addClass('error');
					}

					if(!tel){
						jQuery('input[name="tel"]').addClass('error');
					}

					if(vorname != '' && nachname != '' && geburtsdatum != '' && email != '' && tel != ''){
						if(validateEmail(email)){
							jQuery(currentelement).addClass('fill').removeClass('current').hide();
							jQuery(currentelement).next('.list_step_form').show().addClass('current');
						} else{
							jQuery('input[name="email"]').addClass('error');
						}
					}
				}

				if(stepid == 'step-2'){
					jQuery(currentelement).addClass('fill').removeClass('current').hide();
					jQuery(currentelement).next('.list_step_form').show().addClass('current');
				}

				if(stepid == 'step-3'){
					var state_dropdown = jQuery('input[name="state_dropdown"]').val();
					var location_dropdown = jQuery('input[name="location_dropdown"]').val();
					var workus_dropdown = jQuery('input[name="workus_dropdown"]').val();
					// jQuery(currentelement).addClass('fill').removeClass('current').hide();
					// jQuery(currentelement).next('.list_step_form').show().addClass('current');
				}

				// jQuery(currentelement).addClass('fill').removeClass('current').hide();
				// jQuery(currentelement).next('.list_step_form').show().addClass('current');
				countprogress()
			}
		}else{
			if(jQuery('.list_step_form_main .list_step_form.fill').length > 0){
				jQuery(currentelement).removeClass('current').hide().last().prev().show().addClass('current').removeClass('fill');
				countprogress()
			}
		}
		
	});

	jQuery(document).ready(function() {
		jQuery('.select').niceSelect();
	  });
});



jQuery('.form_row_state .form_col_state .state_indicate_box label').click(function() {
	var id = jQuery(this).attr('data-id');
	jQuery('#conformation_modal').modal('show');
	jQuery('.confirm_btn_modal').attr('data-id',id);
	jQuery('.return_btn_modal').attr('data-id',id);
	jQuery('.language_conformation .btn-close').attr('data-id',id);
});

jQuery('.confirm_btn_modal').click(function() {
	var dataid = jQuery(this).attr('data-id');
	document.getElementById(dataid).checked = true;
	jQuery("#conformation_modal").modal('hide');
});

jQuery('.return_btn_modal').click(function() {
	var dataid = jQuery(this).attr('data-id');
	document.getElementById(dataid).checked = false;
	jQuery("#conformation_modal").modal('hide');
});

jQuery('.language_conformation .btn-close').click(function() {
	var dataid = jQuery(this).attr('data-id');
	document.getElementById(dataid).checked = false;
	jQuery("#conformation_modal").modal('hide');
});


/*============ Slick-Slider Function End ============*/